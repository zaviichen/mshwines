#!/usr/bin/python
# -*- coding: utf-8 -*-
#

import sqlite3
import shutil

conn = sqlite3.connect('fixtures/wine.db')
c = conn.cursor()

dir = 'public/media/wineimg/'

c.execute('select Id, Image from product')
for (id, image) in c.fetchall():
    if image is not None:
        old_name = dir + image
        new_name = dir + '%d.jpg' % id
        print '%d: %s => %s' % (id, old_name, new_name)
        shutil.copyfile(old_name, new_name)